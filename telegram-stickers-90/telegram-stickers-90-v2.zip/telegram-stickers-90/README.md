# Telegram stickers (90)

Prepared from the provided contact sheet for Telegram static sticker import.

- 90 static WebP files
- 512 x 512 px transparent canvas
- one sticker per file
- filenames follow visual reading order: sticker_001.webp ... sticker_090.webp
- all files are below Telegram's 512 KB static-sticker limit

Source-sheet note: the printed numbering on the contact sheet is inconsistent (including duplicated/missing labels and overlapping artwork), so filenames use visual reading order rather than the printed labels. The overlapping artwork around the printed 12/13 area was separated on a best-effort basis from the flattened source.
